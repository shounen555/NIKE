import { arrowRight } from "../assets/icons";
import { motion } from "framer-motion";
const Button = (props) => {
  return (
    <motion.button
      whileHover={{ scale: 1.2 }}
      whileTap={{ scale: 1.1 }}
      className={`font-montserrat ${props.bgColor} ${props.fullWidth ? "w-full" : ""} ${
        props.textColor === "text-black"
          ? "text-black border-black"
          : "text-white"
      } text-lg py-4 px-8 rounded-full flex gap-3 items-center justify-center border `}
    >
      {props.label}
      <img src={props.imgURL} alt="" />
    </motion.button>
  );
};

export default Button;
