import { headerLogo } from "../assets/images";
import { hamburger } from "../assets/icons";
import { x } from "../assets/icons";
import { navLinks } from "../constants"; // Assuming navLinks is an array of objects containing label and href properties
import { useState } from "react";

const Nav = () => {
  const [open, setOpen] = useState(false); // State to manage the open/close state of the navigation

  return (
    <header className="lg:padding-x lg:py-8 max-lg:bg-white  lg:absolute z-10 w-full fixed">
      {/* Main navigation */}
      <nav className="flex justify-between items-center px-5 lg:px-0 py-4 lg:p-0 max-container">
        {/* Logo */}
        <div></div>
        <a href="/" className="justify-self-center ">
          <img src={headerLogo} alt="logo" width={130} height={29} />
        </a>
        <ul className="flex flex-1 gap-16 justify-center items-center max-lg:hidden">
          {navLinks.map((link) => (
            <li key={link.label}>
              <a
                className="font-montserrat  leading-normal text-lg text-slate-gray"
                href={link.href} // Link URL
              >
                {link.label}{" "}
              </a>
            </li>
          ))}
        </ul>
        {/* Sign in and Explore links */}
        <div className="font-montserrat  leading-normal text-lg font-medium  max-lg:hidden wide:mr-24">
          <a href="/" className="">
            Sign in
          </a>
          <span className="px-2">/</span>
          <a href="/">Explore now</a>
        </div>
        {/* Hamburger button */}
        <button className="hidden max-lg:block " onClick={() => setOpen(!open)}>
          <img
            src={open ? x : hamburger}
            alt="hamburger"
            width={25}
            height={25}
          />
        </button>
        {/* Links */}
      </nav>

      {/* Dropdown navigation when 'open' is true */}
      {open && (
        <nav className=" animated-nav hidden max-lg:block  shadow-lg  bg-white">
          <ul className="flex flex-col mt-3 w-full">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href} // Link URL
                className="py-2 px-5 hover:bg-slate-50 rounded-md font-montserrat  leading-normal text-lg text-slate-gray"
              >
                {link.label}
              </a>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
};

export default Nav;
