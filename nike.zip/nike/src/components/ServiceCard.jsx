const ServiceCard = (props) => {
  return (
    <div className="flex flex-col flex-1 shadow-3xl px-10 py-16 rounded-3xl sm:min-w-80">
      <div className="flex justify-center items-center bg-coral-red rounded-full p-2 w-11 h-11">
        <img src={props.imgURL} alt="icon" />
      </div>

      <p className="font-palanquin font-bold text-3xl mt-5">{props.label}</p>
      <p className="font-montserrat text-slate-gray text-lg leading-normal break-words mt-5">
        {" "}
        {props.subtext}
      </p>
    </div>
  );
};

export default ServiceCard;
