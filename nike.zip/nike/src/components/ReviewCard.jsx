import React from "react";
import { star } from "../assets/icons";

const ReviewCard = (props) => {
  return (
    <div className="flex shadow-lg flex-col p-4 rounded-xl justify-center items-center sm:min-w-[360px] hover:scale-105 transition-transform duration-200">
      <img src={props.imgURL} alt="" className="w-28 rounded-full" />
      <p className="font-montserrat text-lg text-slate-gray mx-auto max-w-sm text-center mt-6 leading-7">
        {props.feedback}{" "}
      </p>
      <div className="flex gap-4 mt-8">
        <img src={star} alt="" />
        <p className="font-montserrat  text-xl"> ({props.rating})</p>
      </div>

      <p className="font-montserrat font-semibold text-2xl  mt-4 ">
        {props.customerName}
      </p>
    </div>
  );
};

export default ReviewCard;
