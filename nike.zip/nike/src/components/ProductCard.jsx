import React from "react";
import { star } from "../assets/icons";
const ProductCard = (props) => {
  return (
    <div className="flex flex-col flex-1 shadow-lg p-4 rounded-xl hover:scale-110  transition-transform duration-200 cursor-pointer w-full max-sm:w-full max-w-[330px] ">
      <img src={props.imgURL} alt="" className="w-[282px] h-[282px]" />
      <div className="flex gap-4 mt-8">
        <img src={star} alt="" />{" "}
        <p className="font-montserrat  text-xl"> ({props.rating})</p>
      </div>
      <p className="font-montserrat font-semibold text-xl mt-4">{props.name}</p>
      <p className="font-montserrat font-semibold text-2xl text-coral-red mt-4">
        {props.price}
      </p>
    </div>
  );
};

export default ProductCard;
