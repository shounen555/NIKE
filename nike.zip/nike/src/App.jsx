import {
  Hero,
  Footer,
  CustomerReviews,
  PopularProducts,
  Services,
  SpecialOffers,
  Subscribe,
  SuperQuality,
} from "./sections/index";
import { motion, useScroll, useSpring } from "framer-motion";
import { Nav } from "./components";

const App = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });
  return (
    <main className="relative">

      <motion.div
        className="fixed top-0 left-0 right-0 h-3 bg-coral-red origin-[0%] z-20 skew-x-12"
        style={{ scaleX }}
      />
      <Nav />
      <section className="xl:padding-l wide:padding-r padding-b">
        <Hero />
      </section>
      <section className="padding">
        <PopularProducts />
      </section>
      <section className="padding">
        <SuperQuality />
      </section>
      <section className="padding-x py-10">
        <Services />
      </section>
      <section className="padding">
        <SpecialOffers />
      </section>
      <section className="padding bg-pale-blue">
        <CustomerReviews />
      </section>
      <section className="padding-x sm:py-32 padding-y w-full">
        <Subscribe />
      </section>
      <section className="padding-x  py-10 bg-black">
        <Footer />
      </section>
    </main>
  );
};

export default App;
