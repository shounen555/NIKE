import {ProductCard} from "../components";
import { products } from "../constants";
const PopularProducts = () => {
  return (
    <section id="products" className="max-sm:mt-8 max-container">
      <div className="space-y-6">
        <h1 className="capitalize text-4xl font-palanquin font-bold ">
          our <span className="text-coral-red">popular</span> products
        </h1>
        <p className="font-montserrat text-slate-gray max-w-lg">
          Experience top-notch quality and style with our sought-after
          selections. Discover a world of comfort, design, and value
        </p>
      </div>
      <div className="mt-16 grid xl:grid-cols-4 gap-3 justify-between sm:grid-cols-2 lg:grid-cols-3 grid-cols-1">
        {products.map((product) => (
          <ProductCard key={product.name} {...product} />
        ))}
      </div>
    </section>
  );
};

export default PopularProducts;
