import React from "react";
import { shoes, statistics } from "../constants";
import { bigShoe1 } from "../assets/images";
import { useState } from "react";
import { Button } from "../components";
import { motion } from "framer-motion";
import { arrowRight } from "../assets/icons";
const Hero = () => {
  const [bigShoeImg, setBigShoeImg] = useState(bigShoe1);
  return (
    <section
      id="home"
      className="w-full flex xl:flex-row flex-col justify-center min-h-screen gap-10 max-container"
    >
      <div className="relative xl:w-2/5 flex flex-col justify-center items-start w-full justify-self-start  max-xl:padding-x pt-28 ">
        <p className="text-xl font-montserrat text-coral-red">
          Our Summer collections
        </p>

        <h1 className="mt-10 font-palanquin text-8xl max-sm:text-[72px] max-sm:leading-[82px] font-bold">
          <span className="xl:bg-white xl:whitespace-nowrap relative xl:z-10 pr-10">
            The New Arrival
          </span>
          <br />
          <span className="text-coral-red inline-block mt-3"> Nike </span> Shoes
        </h1>
        <p className="font-montserrat text-slate-gray leading-8 text-lg mt-6 mb-16 sm:max-w-sm">
          Discover stylish Nike arrivals, quality comfort, and innovation for
          your active life.
        </p>

        <Button label="Shop Now" imgURL={arrowRight} bgColor="bg-coral-red" textColor="text-white"/>

        <div className="flex justify-start gap-16 w-full mt-20 max-sm:justify-between max-sm:gap-0">
          {statistics.map((stat) => (
            <div key={stat.value}>
              <p className="font-palanquin font-bold text-4xl max-sm:text-3xl">
                {stat.value}{" "}
              </p>
              <p className="font-montserrat text-slate-gray">{stat.label} </p>
            </div>
          ))}
        </div>
      </div>
      <div className="flex justify-center items-center max-xl:py-40  flex-1 bg-hero bg-cover bg-center relative">
        <motion.img
          drag
          dragConstraints={{
            top: -50,
            left: -50,
            right: 50,
            bottom: 50,
          }}
          src={bigShoeImg}
          alt="shoe collection"
          width={610}
          height={502}
          className="object-contain relative "
        />

        <div className="absolute -bottom-[5%]  flex justify-between gap-6 max-sm:mx-6">
          {shoes.map((shoe) => (
            <div
              key={shoe.thumbnail}
              className={`flex justify-center items-center bg-card bg-cover bg-center rounded-xl sm:w-40 sm:h-40 max-sm:p-4 cursor-pointer ${
                shoe.bigShoe === bigShoeImg
                  ? "border-coral-red"
                  : "border-transparent"
              }  border-2  hover:scale-105 transition-all `}
              onClick={() => setBigShoeImg(shoe.bigShoe)}
            >
              <img src={shoe.thumbnail} alt="" className="object-contain" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
