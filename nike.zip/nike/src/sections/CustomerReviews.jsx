import { ReviewCard } from "../components";
import { reviews } from "../constants";
const CustomerReviews = () => {
  return (
    <section className="max-container ">
      <div className="flex-1">
        <p className="font-palanquin font-bold text-4xl text-center">
          What Our <span className="text-coral-red">Customers </span>
          Say?
        </p>
        <p className="mt-6 font-montserrat text-slate-gray text-lg leading-8 max-w-xl text-center mx-auto">
          Hear genuine stories from our satisfied customers about their
          exceptional experiences with us.
        </p>
      </div>
      <div className="mt-24 flex flex-1 justify-evenly items-center flex-wrap gap-14">
        {reviews.map((review, index) => (
          <ReviewCard key={index} {...review} />
        ))}
      </div>
    </section>
  );
};

export default CustomerReviews;
