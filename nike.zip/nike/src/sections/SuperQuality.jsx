import { Button } from "../components";
import { shoe8 } from "../assets/images";

const SuperQuality = () => {
  return (
    <section className="flex lg:flex-row flex-col gap-10 justify-between items-center  w-full max-container">
      <div className="flex-1  ">
        <h1 className="font-palanquin font-bold text-4xl lg:max-w-lg">
          We Provide You <span className="text-coral-red"> Super Quality</span>{" "}
          Shoes
        </h1>
        <p className="mt-6 font-montserrat text-slate-gray text-lg leading-8 lg:max-w-lg">
          Ensuring premium comfort and style, our meticulously crafted footwear
          is designed to elevate your experience, providing you with unmatched
          quality, innovation, and a touch of elegance.
        </p>
        <p className="mt-6 mb-10 font-montserrat text-slate-gray text-lg leading-8 lg:max-w-lg">
          Our dedication to detail and excellence ensures your satisfaction
        </p>
        <Button
          label="Shop Now"
          bgColor="bg-coral-red"
          textColor="text-white"
        />
      </div>
      <div className="flex justify-center flex-1 items-center">
        <img
          src={shoe8}
          alt="shoe"
          width={570}
          height={522}
          className="object-contain"
        />
      </div>
    </section>
  );
};

export default SuperQuality;
