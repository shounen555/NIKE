import { Button } from "../components";
const Subscribe = () => {
  return (
    <section id="contact-us" className="flex justify-between items-center max-container  max-lg:flex-col  ">
      <p className="font-palanquin font-bold text-4xl lg:max-w-md max-lg:mb-8">
        Sign Up for <span className="text-coral-red"> Updates</span> &
        Newsletter
      </p>

      <div className="flex  lg:w-[40%] w-full justify-between border-2  rounded-full px-4 py-3 max-sm:flex-col max-sm:mb-4">
        <input
          type="text"
          placeholder="jaber.nouaman@um5r.ac.ma"
          className="flex-1 border-none outline-none px-5"
        />
        <div className="min-w-36 max-sm:hidden">
          <Button
            label="Sign in"
            bgColor="bg-coral-red"
            textColor="text-white"
          />
        </div>
      </div>
      <div className="w-full sm:hidden">
        <Button
          label="Sign Up"
          bgColor="bg-coral-red"
          textColor="text-white"
          fullWidth={true}
        />
      </div>
    </section>
  );
};

export default Subscribe;
