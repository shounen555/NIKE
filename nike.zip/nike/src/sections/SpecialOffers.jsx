import { Button } from "../components";
import { offer } from "../assets/images";
import { arrowRight } from "../assets/icons";
const SpecialOffers = () => {
  return (
    <section className="flex lg:flex-row flex-col-reverse gap-10 justify-between items-center  w-full max-container">
      <div className="flex justify-center flex-1 items-center">
        <img
          src={offer}
          alt="offer"
          width={773}
          height={687}
          className="object-contain"
        />
      </div>
      <div className="flex-1  ">
        <h1 className="font-palanquin font-bold text-4xl lg:max-w-lg">
          <span className="text-coral-red">Special </span> Offer
        </h1>
        <p className="mt-6 font-montserrat text-slate-gray text-lg leading-8 lg:max-w-xl">
          Embark on a shopping journey that redefines your experience with
          unbeatable deals. From premier selections to incredible savings, we
          offer unparalleled value that sets us apart.
        </p>
        <p className="mt-6 mb-10 font-montserrat text-slate-gray text-lg leading-8 lg:max-w-xl">
          Navigate a realm of possibilities designed to fulfill your unique
          desires, surpassing the loftiest expectations. Your journey with us is
          nothing short of exceptional.
        </p>
        <div className="flex gap-6 flex-wrap">
          <Button
            label="Shop Now"
            imgURL={arrowRight}
            bgColor="bg-coral-red"
            textColor="text-white"
          />
          <Button
            label="Learn more"
            bgColor="bg-white"
            textColor="text-black"
          />
        </div>
      </div>
    </section>
  );
};

export default SpecialOffers;
