import { services } from "../constants";
import { ServiceCard } from "../components";

const Services = () => {
  return (
    <section
      id="about-us"
      className="flex justify-between flex-wrap items-center gap-10 max-container"
    >
      {services.map((service) => (
        <ServiceCard
          key={service.label}
          imgURL={service.imgURL}
          label={service.label}
          subtext={service.subtext}
        />
      ))}{" "}
    </section>
  );
};

export default Services;
