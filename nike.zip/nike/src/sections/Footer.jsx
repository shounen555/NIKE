import { socialMedia } from "../constants";
const footer = () => {
  new Date().getFullYear(<p>© 2022 NIKE</p>);
  return (
    <section className="max-container">
      {/* <div>
        <div>
          <img src="" alt="" />
          <p className="font-montserrat text-white-400">
            Get shoes ready for the new term at your nearest Nike store. Find
            Your perfect Size In Store. Get Rewards
          </p>
          <div className="flex gap-6">
            {socialMedia.map((social, index) => (
              <div className="bg-white rounded-full p-2">
                <img
                  key={index}
                  src={social.src}
                  alt={social.alt}
                  className="w-8 h-8"
                />
              </div>
            ))}
          </div>
        </div>
        <div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div> */}
      <div className="font-montserrat text-white-400 flex justify-between">
        <p>© {new Date().getFullYear()} NIKE</p>
        <p>Terms of Use | Privacy Policy</p>
      </div>
    </section>
  );
};

export default footer;
